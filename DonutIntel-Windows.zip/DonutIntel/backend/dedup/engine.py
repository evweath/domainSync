"""
Deduplication engine for Donut Intel Platform (F06–F11).
Detects duplicate products WITHIN a single store (source site).
Duplicates = the same product listed more than once in the same store.
The same product appearing in different stores is NOT a duplicate (that is a
cross-store comparison, surfaced on the Store Comparison page).
"""
import json
import logging
from datetime import datetime
from typing import List, Optional, Tuple

from sqlalchemy.orm import Session

from backend.config import config
from backend.database.models import (
    CompetitorProductMatch,
    DuplicateCandidate,
    Product,
    ProductSource,
    ProductVersion,
)
from backend.dedup.matchers import compute_confidence

logger = logging.getLogger(__name__)


# System of record: canonical fields (incl. price) mirror this store when present.
# Stored in the DB as source_site="donut-equipment.com" (its Shopify store is
# equipmentplus.myshopify.com — see the store-architecture notes).
SOR_SITE = "donut-equipment.com"


def recompute_product_prices(session: Session, product: Product) -> bool:
    """Set ``price_canonical`` from the system-of-record store, and
    ``price_min``/``price_max`` to the range across active source prices.

    Canonical is always a REAL store price — never a synthetic average. Per the
    SoR model it must mirror the donut-equipment.com (equipmentplus) listing
    whenever the product has one; only products with no SoR source fall back to
    the most-recently-scraped store price. It feeds exports, reports, competitor
    comparison, price filters and dedup scoring. Returns True if a price was set.
    """
    session.flush()  # ensure freshly re-attached sources are visible
    srcs = (
        session.query(ProductSource)
        .filter(
            ProductSource.product_id == product.id,
            ProductSource.is_active == True,
            ProductSource.source_price != None,
            ProductSource.source_price > 0,
        )
        .all()
    )
    prices = [s.source_price for s in srcs]
    if not prices:
        return False
    # Prefer the SoR store's most-recent price; fall back to latest overall.
    sor_srcs = [s for s in srcs if s.source_site == SOR_SITE]
    pick_from = sor_srcs or srcs
    latest = max(pick_from, key=lambda s: s.scraped_at or datetime.min)
    product.price_canonical = latest.source_price
    product.price_min = min(prices)
    product.price_max = max(prices)
    return True


def recompute_all_product_prices(session: Session) -> int:
    """Backfill: recompute prices for every active product from its active
    sources. Use to correct products whose canonical price was previously a
    synthetic average. Returns the number of products updated."""
    updated = 0
    for product in session.query(Product).filter(Product.is_active == True).all():
        if recompute_product_prices(session, product):
            updated += 1
    session.commit()
    return updated


class DeduplicationEngine:
    def __init__(self):
        self.auto_merge_threshold: float = config.get(
            "deduplication", "auto_merge_threshold", default=85
        )
        self.review_threshold: float = config.get(
            "deduplication", "manual_review_threshold", default=60
        )
        self.price_weight: int = config.get("deduplication", "price_weight", default=40)
        self.model_weight: int = config.get("deduplication", "model_number_weight", default=35)
        self.manufacturer_weight: int = config.get("deduplication", "manufacturer_weight", default=15)
        self.title_weight: int = config.get("deduplication", "title_weight", default=20)
        self.desc_weight: int = config.get("deduplication", "description_weight", default=10)
        self.price_tolerance: float = config.get(
            "deduplication", "price_tolerance_percent", default=2.0
        )

    def run(
        self,
        session: Session,
        product_ids: Optional[List[int]] = None,
        domain_filters: Optional[List[str]] = None,
    ) -> dict:
        """
        Run deduplication across all products (or a subset).
        Only compares products that share a common store (source site) —
        duplicates are listings of the same product within one store.
        Returns summary stats.
        """
        logger.info("Starting deduplication run")
        stats = {
            "comparisons": 0,
            "auto_merged": 0,
            "flagged_for_review": 0,
            "skipped_existing": 0,
        }

        # Load all active products with their source site info
        query = session.query(Product).filter(Product.is_active == True)
        if product_ids:
            query = query.filter(Product.id.in_(product_ids))
        if domain_filters:
            query = query.filter(
                Product.sources.any(
                    ProductSource.source_site.in_(domain_filters) & (ProductSource.is_active == True)
                )
            )
        products = query.all()

        logger.info(f"Comparing {len(products)} products for duplicates")

        # Build a list: (product, set_of_source_sites)
        product_data = []
        for p in products:
            sites = {s.source_site for s in p.sources if s.is_active}
            product_data.append((p, sites))

        # O(n²) comparison — acceptable for <10k products; blocking can be added later
        already_checked = set()
        for i, (prod_a, sites_a) in enumerate(product_data):
            for j, (prod_b, sites_b) in enumerate(product_data):
                if i >= j:
                    continue
                # Duplicates live WITHIN one store: only compare products that
                # share at least one common source site. Products that appear
                # only in different stores are not duplicates of each other.
                if not (sites_a & sites_b):
                    continue
                # Don't compare products that already have a resolved duplicate record
                pair_key = (min(prod_a.id, prod_b.id), max(prod_a.id, prod_b.id))
                if pair_key in already_checked:
                    stats["skipped_existing"] += 1
                    continue
                already_checked.add(pair_key)

                # Check if a duplicate record already exists (any status)
                existing = (
                    session.query(DuplicateCandidate)
                    .filter(
                        DuplicateCandidate.primary_product_id == pair_key[0],
                        DuplicateCandidate.secondary_product_id == pair_key[1],
                    )
                    .first()
                )
                if existing and existing.status in ("merged", "rejected"):
                    stats["skipped_existing"] += 1
                    continue

                stats["comparisons"] += 1
                confidence, factor_scores = compute_confidence(
                    price_a=prod_a.price_canonical,
                    price_b=prod_b.price_canonical,
                    model_a=prod_a.model_number,
                    model_b=prod_b.model_number,
                    manufacturer_a=prod_a.manufacturer,
                    manufacturer_b=prod_b.manufacturer,
                    title_a=prod_a.canonical_title,
                    title_b=prod_b.canonical_title,
                    desc_a=prod_a.canonical_description,
                    desc_b=prod_b.canonical_description,
                    sku_a=prod_a.sku,
                    sku_b=prod_b.sku,
                    price_weight=self.price_weight,
                    model_weight=self.model_weight,
                    manufacturer_weight=self.manufacturer_weight,
                    title_weight=self.title_weight,
                    description_weight=self.desc_weight,
                    price_tolerance_pct=self.price_tolerance,
                )

                if confidence < self.review_threshold:
                    continue

                # Merging is always manual now: every detected duplicate is
                # recorded as a pending candidate for the user to merge/reject.
                # Nothing is auto-merged regardless of confidence.
                if existing:
                    # Update score if re-running
                    existing.confidence_score = confidence
                    existing.match_reasons_json = json.dumps(factor_scores)
                    if existing.status == "pending":
                        stats["flagged_for_review"] += 1
                else:
                    candidate = DuplicateCandidate(
                        primary_product_id=pair_key[0],
                        secondary_product_id=pair_key[1],
                        confidence_score=confidence,
                        match_reasons_json=json.dumps(factor_scores),
                        status="pending",
                    )
                    session.add(candidate)
                    session.flush()
                    stats["flagged_for_review"] += 1

                # Commit + release the write lock periodically. With ~5k
                # products the inner loop runs ~13M times, and SQLite only
                # allows ONE writer at a time. Without periodic commits the
                # write transaction stays open for the entire pass and any
                # other endpoint that wants to write (scheduler, scrapers,
                # API saves) blocks on `busy_timeout` and eventually fails
                # with `database is locked`. 250 candidates ≈ a few seconds
                # of work and keeps each transaction small.
                if (stats["auto_merged"] + stats["flagged_for_review"]) % 250 == 0:
                    session.commit()

        session.commit()
        logger.info(f"Deduplication complete: {stats}")
        return stats

    def _merge_products(
        self,
        session: Session,
        primary: Product,
        secondary: Product,
        candidate: DuplicateCandidate,
        auto: bool = True,
        notes: str = "",
        resolved_by: str = "auto",
    ) -> None:
        """
        Merge secondary into primary:
        - Move all sources from secondary → primary
        - Merge images, options, tags, notes
        - Consolidate price (min/max/canonical)
        - Archive version of primary before changes (F55)
        - Deactivate secondary product
        """
        # Archive current state of primary (F55)
        self._archive_version(session, primary, changed_fields=["merge"])

        # Re-attach secondary sources to primary
        for src in secondary.sources:
            # Check if primary already has a source from the same site+URL
            exists = any(
                s.source_site == src.source_site and s.source_url == src.source_url
                for s in primary.sources
            )
            if not exists:
                src.product_id = primary.id

        # Merge images
        existing_image_urls = {img.source_url for img in primary.images}
        for img in secondary.images:
            if img.source_url not in existing_image_urls:
                img.product_id = primary.id

        # Merge options
        existing_options = {
            (o.option_group, o.option_value) for o in primary.options
        }
        for opt in secondary.options:
            if (opt.option_group, opt.option_value) not in existing_options:
                opt.product_id = primary.id

        # Recompute prices from the combined active sources. Canonical is the
        # most-recent real source price, NOT an average of the two products'
        # prices (averaging produced a synthetic price matching no store).
        recompute_product_prices(session, primary)

        # Fill in missing fields from secondary
        if not primary.manufacturer and secondary.manufacturer:
            primary.manufacturer = secondary.manufacturer
        if not primary.model_number and secondary.model_number:
            primary.model_number = secondary.model_number
        if not primary.sku and secondary.sku:
            primary.sku = secondary.sku
        if not primary.canonical_description and secondary.canonical_description:
            primary.canonical_description = secondary.canonical_description

        primary.updated_at = datetime.utcnow()

        # Re-link competitor matches from secondary → primary
        secondary_matches = (
            session.query(CompetitorProductMatch)
            .filter(CompetitorProductMatch.master_product_id == secondary.id)
            .all()
        )
        existing_match_keys = {
            (m.competitor_id, m.competitor_url)
            for m in session.query(CompetitorProductMatch)
            .filter(CompetitorProductMatch.master_product_id == primary.id)
            .all()
        }
        for m in secondary_matches:
            key = (m.competitor_id, m.competitor_url)
            if key not in existing_match_keys:
                m.master_product_id = primary.id
                existing_match_keys.add(key)
            # duplicate URL on primary already — leave secondary match as-is;
            # it will become unreachable once secondary is deactivated (harmless)

        # Deactivate secondary
        secondary.is_active = False

        # Update candidate record
        candidate.status = "merged"
        candidate.resolved_at = datetime.utcnow()
        candidate.resolved_by = resolved_by
        candidate.resolution_notes = notes or ("Auto-merged" if auto else "Manual merge")

        session.flush()

    def reject_duplicate(
        self,
        session: Session,
        candidate_id: int,
        notes: str = "",
        resolved_by: str = "user",
    ) -> bool:
        candidate = session.get(DuplicateCandidate, candidate_id)
        if not candidate:
            return False
        candidate.status = "rejected"
        candidate.resolved_at = datetime.utcnow()
        candidate.resolved_by = resolved_by
        candidate.resolution_notes = notes
        session.commit()
        return True

    def manual_merge(
        self,
        session: Session,
        candidate_id: int,
        notes: str = "",
        resolved_by: str = "user",
    ) -> bool:
        candidate = session.get(DuplicateCandidate, candidate_id)
        if not candidate:
            return False
        if candidate.status == "merged":
            return True
        primary = session.get(Product, candidate.primary_product_id)
        secondary = session.get(Product, candidate.secondary_product_id)
        if not primary or not secondary:
            return False
        self._merge_products(session, primary, secondary, candidate, auto=False, notes=notes, resolved_by=resolved_by)
        session.commit()
        return True

    def _archive_version(self, session: Session, product: Product, changed_fields: list) -> None:
        """Save a version snapshot of product before modification (F55)."""
        import json as _json
        snapshot = {
            "canonical_title": product.canonical_title,
            "canonical_description": product.canonical_description,
            "manufacturer": product.manufacturer,
            "model_number": product.model_number,
            "sku": product.sku,
            "price_canonical": product.price_canonical,
            "price_min": product.price_min,
            "price_max": product.price_max,
            "category": product.category,
        }
        version = ProductVersion(
            product_id=product.id,
            version=product.version,
            canonical_title=product.canonical_title,
            canonical_description=product.canonical_description,
            manufacturer=product.manufacturer,
            model_number=product.model_number,
            price_canonical=product.price_canonical,
            changed_fields=_json.dumps(changed_fields),
            snapshot_json=_json.dumps(snapshot),
        )
        session.add(version)
        product.version = (product.version or 1) + 1
